import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-function',
  templateUrl: './function.component.html',
  styleUrls: ['./function.component.css']
})
export class FunctionComponent implements OnInit {
result = null;
  constructor() {
    this.result = this.show();
  }

  ngOnInit() {
  }
  //in loc de Message putem pune string, boolean, s.a. - in alte exemple
  show(): Message{
  return new Message( 'Hi')
  // return 10;
  }
}
//aici putem scri js functii
//tipizarea stricta
function add (x: number,y: number): number{
  // return (x+y)+'';
     return x+y;
}
console.log(add (10,20));
// console.log(add ('10','20'));
class Message{
  text = ''
  constructor(text){
  this.text = text;
  }
}
